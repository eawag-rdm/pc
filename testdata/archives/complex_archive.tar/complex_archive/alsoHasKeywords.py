# This file will contain some keywords

GLOBAL_VAR = "Q:/Abteilungsprojekte"
HARDCODED_PATH= "C:/Users/YOU/should/not/have/hardcoded/paths"

def hello():
    print("hello")


