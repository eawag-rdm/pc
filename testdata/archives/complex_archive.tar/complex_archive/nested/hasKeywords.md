This file might also have Passwords or other sensitive information like Q:/Abteilungsprojekte.
